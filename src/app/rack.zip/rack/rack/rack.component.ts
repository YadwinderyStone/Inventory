import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RackService } from '../rack.service';
import { TranslationService } from '../../core/services/translation.service';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../../core/security/auth.service';
import { Warehouse } from '../../core/domain-classes/warehouse';
import { WarehouseService } from '../../core/services/warehouse.service';
import { Guid } from 'guid-typescript';
@Component({
  selector: 'app-rack',
  templateUrl: './rack.component.html',
  styleUrls: ['./rack.component.scss']
})
export class RackComponent implements OnInit {
  rackList: any[] = [];
  isDropdownOpen: boolean = false;
  rackForm: FormGroup
  visible: boolean;
  data: any[] = [];
  loading: boolean = true; 
  wareHouseData: any[] = [];
  addItem: boolean = false
  isId: any;
  warehouses: Warehouse[] = [];
  constructor(private fb: FormBuilder, private rackService: RackService, private authService: AuthService, private toastrService: ToastrService, public translationService: TranslationService, private warehouseService: WarehouseService)
  {
    this.getRack();
  };
  ngOnInit() {
    this.initializeFormData();
    this.getWarehouse();
  }
  getWarehouse() {
    debugger;
    this.warehouseService.getAll().subscribe(warehouses => {
      this.warehouses = warehouses;
      console.log(this.warehouses)
    })
  }
  initializeFormData() {
    this.rackForm = this.fb.group({
      Id: [Guid, Validators.required],
/*      RackID:[''],*/
      RackName: ['', Validators.required],
      RackDescription: [''],
    });
  }
  getRack() {
    this.loading = true
    this.rackService.getAllRack().subscribe((res) => {
      debugger;
      this.data = res

      this.rackList = this.data;
      console.log(this.rackList, "rackList")
   


      this.loading = false
    },
      error => {
        this.loading = false
        /*  this.localToast.handleHttpErrorResponse(error)*/
        this.toastrService.error(this.translationService.getValue('error'));
      }
    )}

  showDialog() {
    this.rackForm.reset();
    this.isId = ''
    this.visible = true;
  }

  edit(item: any) {
    this.isId = item.id;
    item.warehouseName = this.wareHouseData[0];
    this.rackForm.patchValue(item)
    this.visible = true;
  }

  submitForm() {
    debugger
    if (this.rackForm.invalid) {
      this.authService.markAsDirty(this.rackForm)
      this.rackForm.markAllAsTouched();
      return
    }
    let fb: any = this.rackForm.value;
    this.addItem = true;
    if (this.isId) {
      var data = {
        RackID: this.isId, Id: fb.Id, RackName: fb.RackName, RackDescription: fb.RackDescription
      }
      var _retun = this.rackService.updateRack(data).subscribe((res) => {
        debugger
        /* this.localToast.presentSuccess(res.message, "", 3000)*/
        this.toastrService.success(this.translationService.getValue('Update Successully'));
        this.getRack();
        this.visible = false;
        this.addItem = false;
        this.rackForm.reset();
      },
        error => {
          debugger
          this.getRack();
          this.addItem = false;
          this.toastrService.error(this.translationService.getValue('error'));
        })
    } else {
      var _retun=this.rackService.AddRack(fb).subscribe((res) => {
        this.toastrService.success(this.translationService.getValue('Save Successully'));
        this.getRack();
        this.visible = false;
        this.addItem = false;
        this.rackForm.reset();
      },
        error => {
          this.addItem = false;
          this.getRack();
          this.visible = false;
          this.toastrService.error(this.translationService.getValue('error'));
        }
      )
    }
  }
  editRack(item: any, event: MouseEvent) {
    debugger
    item.editable = true;
    this.isId = item.rackID;
    this.rackForm.controls["Id"].setValue(item.warehouseId);
    this.rackForm.controls["RackName"].setValue(item.rackName);
    this.rackForm.controls["RackDescription"].setValue(item.rackDescription);
    this.visible = true;
    console.log("Saving:", item);
    this.isDropdownOpen = true;
    this.toastrService.success(this.translationService.getValue('UPDATED_SUCCESSFULLY'));
  }

  deleteRack(item: any) {
    debugger;
    this.isId = item.rackID;
    this.rackService.deleteRack(item.rackID).subscribe(c => {
      this.toastrService.success(this.translationService.getValue('DELETED_SUCCESSFULLY'));
      item.editable = !item.editable;
      this.getRack();
    });
  }

}




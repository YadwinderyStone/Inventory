import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Router, RouterLinkActive } from '@angular/router';
import { TranslationService } from '../../core/services/translation.service';
import { MatDialog } from '@angular/material/dialog';
import { HttpClient } from '@microsoft/signalr';
import { InventoryService } from '../inventory.service';

@Component({
  selector: 'app-bulk-upload-inventory-list',
  templateUrl: './bulk-upload-inventory-list.component.html',
  styleUrls: ['./bulk-upload-inventory-list.component.scss'],
})
export class BulkUploadInventoryListComponent implements OnInit {
  displayedColumns: string[] = ['action', 'imageUrl', 'name', 'brandName', 'categoryName', 'unitName', 'purchasePrice', 'salesPrice', 'mrp', 'warehouse'];
  filteredList: any[] = []; // Filtered list based on search query
  searchQuery: string = '';
  @ViewChild('dropdownMenu') dropdownMenu: ElementRef;
  isDropdownOpen: boolean = false;
  IsForUpdate: boolean = true
  constructor(
    private router: Router,
    private dialog: MatDialog,
    public translationService: TranslationService,
    private inventoryservice: InventoryService
  ) {
    this.filteredList = this.theList;  }

  ngOnInit(): void {
    this.inventoryservice.getInventoruBulk().subscribe(c => {
      this.theList = [...c];
      this.filteredList = this.theList;
      console.log(this.theList, "inventrybulk")

    });
  }
  theList: any = [];
  getinventorubulk() {
    debugger;
    this.inventoryservice.getInventoruBulk().subscribe(c => {
      this.theList = [...c];
      this.filteredList = this.theList;
      console.log(this.theList,"inventrybulk")

    });
  }
  filterList() {
    debugger
    if (!this.searchQuery.trim()) {
      // If search query is empty, show all items
      this.filteredList = this.theList;
    } else {
      // Filter the list based on search query
      const query = this.searchQuery.toLowerCase().trim(); 
      this.filteredList = this.theList.filter(item =>
        item.sourceName.toLowerCase().includes(query)
      );
    }
  }
  toggleDropdown(item: any) {
    debugger
    if (!item.editable) {
      this.isDropdownOpen = !this.isDropdownOpen;
      if (this.isDropdownOpen) {
        this.dropdownMenu.nativeElement.focus(); // Optional: Focus the dropdown menu for keyboard accessibility
      }
    }
  }
  editProduct(item: any, event: MouseEvent) {
    debugger
    this.IsForUpdate = false;
    event.preventDefault(); // Prevent default behavior (e.g., form submission or link navigation)
    item.editable = !item.editable;
    console.log("Saving:", item);
    this.isDropdownOpen = false;
  }

}

import { Supplier } from "./supplier";

export class SupplierList {
    suppliers: Supplier[];
    totalCount: number;
}
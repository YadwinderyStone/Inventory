export interface PurchaseOrderItemTax{
  id?: string;
  purchaseOrderItemId?: string;
  taxId?: string;
  taxName?: string;
  taxPercentage?: string;
}

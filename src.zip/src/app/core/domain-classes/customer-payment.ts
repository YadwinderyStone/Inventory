export class CustomerPayment {
    id: string;
    customerName: string;
    totalAmount: number;
    totalPaidAmount: number;
    totalPendingAmount: number;
}
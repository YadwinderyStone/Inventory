export class EmailParameter {
    parameter: string;
    value: string;
}
import { InquiryAttachment } from './inquiry-attachment';

export interface InquiryAttachmentDialog {
  inquiryId: string,
  inquiryAttachment?: InquiryAttachment
}

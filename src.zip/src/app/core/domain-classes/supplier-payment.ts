export class SupplierPayment {
    id: string;
    supplierName: string;
    totalAmount: number;
    totalPaidAmount: number;
    totalPendingAmount: number;
}
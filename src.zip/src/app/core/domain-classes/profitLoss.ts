export class ProfitLoss
    {
        total:number
        totalTax:number
        totalDiscount:number
        paidPayment:number
        totalItem:number
    }
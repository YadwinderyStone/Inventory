export abstract class ResourceParameter {
  fields = '';
  orderBy = '';
  searchQuery = '';
  pageSize = 30;
  skip = 0;
  name = '';
  totalCount = 0;
}

export interface PurchaseOrderShort {
  purchaseOrderId: string;
  purchaseOrderName: string;
  supplierName: string;
  supplierId: string;
  quantity: number;
}

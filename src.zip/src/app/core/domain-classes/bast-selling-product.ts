export class BestSellingProudct {
    name: string;
    count: number;
}
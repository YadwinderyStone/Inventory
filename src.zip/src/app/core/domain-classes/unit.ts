export class Unit {
    id: string;
    name: string;
}
export class SalesVsPurchase {
    date: Date;
    totalPurchase: number;
    totalSales: number;
}
export interface BulkInventoryModel { 
  Files: File[];
}

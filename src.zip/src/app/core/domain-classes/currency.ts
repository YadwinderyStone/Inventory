export class Currency {
    id: string;
    name: string;
    symbol: string;
}
export interface InquiryProduct {
  productId: string;
  inquiryId: string;
  name: string;
}

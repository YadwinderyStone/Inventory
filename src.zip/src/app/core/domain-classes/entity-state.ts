export enum EntityState {
  Added,
  Modified,
  Deleted,
  Unchanged
}

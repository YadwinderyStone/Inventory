export enum DeliveryStatusEnum{
  UnDelivery = 0,
  Pending_Delivery = 1,
  Partially_Delivery = 2,
  Completely_Delivery = 3
}

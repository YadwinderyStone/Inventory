export class Tax {
    id: string;
    name: string;
    percentage: number;
}
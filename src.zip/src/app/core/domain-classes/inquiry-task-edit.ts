import { InquiryTask } from './inquiry-task';

export interface InquiryTaskEdit {
  inquiryId?: string;
  inquiryTask?: InquiryTask;
}

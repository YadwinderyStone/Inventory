export class InquirySource {
    name: string;
    id: string;
}
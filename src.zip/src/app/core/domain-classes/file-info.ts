export class FileInfo {
  src?: string = '';
  name?: string = '';
  extension?: string = '';
  fileType?: string='';
  fileName?: string;
  id?: string;
}

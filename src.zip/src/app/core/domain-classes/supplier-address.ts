export interface SupplierAddress {
  id?: string;
  supplierId?: string;
  address?: string;
  countryName?: string;
  cityName?: string;
}

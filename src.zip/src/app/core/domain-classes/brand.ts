export class Brand {
    id?: string;
    name: string;
    imageUrl: string;
    imageUrlData?: string;
    isImageChanged?: boolean;
}
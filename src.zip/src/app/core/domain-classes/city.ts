export interface City {
    id: string;
    cityName: string;
    countryId: string;
  }
  
export enum ApplicationEnums {
  Reminder = 0,
  SalesOrder = 1,
  PurchaseOrder = 2,
  Inquiry = 3
}

export class Warehouse {
    id: string;
    name: string;
    address: string;
    contactPerson: string;
    mobileNumber: string;
    email: string;
}
import { Customer } from './customer';

export class CustomerList {
    customers: Customer[];
    totalCount: number;
}

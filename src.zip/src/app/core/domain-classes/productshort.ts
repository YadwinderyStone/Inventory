export class ProductShort {
  id: string;
  name?: string;
  stock?: number;
  unitName?: string;
  unitCode?: string;
}

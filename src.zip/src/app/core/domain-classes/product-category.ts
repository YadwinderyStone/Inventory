export class ProductCategory {
    id: string;
    name: string;
    parentId: string;
    description: string;
    deafLevel?: number;
    index?: number;
}
export interface OnlineUser {
  id: string;
  email: string;
  connectionId: string;
}

export interface InquiryStatus {
  id: string;
  name: string;
}

export class Email {
    to?: string;
    name?: string;
    subject?: string;
    body?: string;
}
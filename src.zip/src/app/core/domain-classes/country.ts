export interface Country {
    id: string;
    countryName: string;
  }
  
export interface DeliveryMethod {
    id?: string;
    name: string;
}

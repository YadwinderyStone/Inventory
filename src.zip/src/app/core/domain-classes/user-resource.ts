import { ResourceParameter } from './resource-parameter';

export class UserResource extends ResourceParameter {
}

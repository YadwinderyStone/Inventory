export interface DashboardStaticatics{
  totalPurchase: number;
  totalSales: number;
  totalSalesReturn: number;
  totalPurchaseReturn: number;

  totalwarehouseReturn: number,
  totaluserReturn: number,
  totalvenderReturn: number,
  totalInventotyReturn: number,
  totalProductReturn: number,

}

export class ProductTax {
    productId?: string;
    taxId: string;
}
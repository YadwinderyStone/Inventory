export class ExpenseCategory {
    id: string;
    name: string;
}
export class Testimonial {
    id?: string;
    name?: string;
    designation: string;
    message: string;
    isActive: boolean;
    createdDate: Date;
    url: string;
}
import { ResourceParameter } from "./resource-parameter";

export class InventoryHistoryResourceParameter extends ResourceParameter {
    productId: string;
}